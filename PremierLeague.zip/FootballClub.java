package lk.programming.OOPCoursework;

public class FootballClub extends SportsClub implements Comparable<FootballClub> {

    //declaring all the instance variables of FootballClub
    private int numWins;
    private int numDraws;
    private int numDefeats;
    private int goalsReceived;
    private int goalsScored;
    private int points;
    private int numOfMatches;

    //default FootballClub constructor
    public FootballClub() {}

    //parameterized FootballClub constructor
    public FootballClub(String clubName, String location, int telNum, int numWins, int numDraws, int numDefeats,
                        int goalsReceived, int goalsScored, int points, int numOfMatches) {
        super(clubName, location, telNum);
        this.numWins = numWins;
        this.numDraws = numDraws;
        this.numDefeats = numDefeats;
        this.goalsReceived = goalsReceived;
        this.goalsScored = goalsScored;
        this.points = points;
        this.numOfMatches = numOfMatches;
    }

    //generating getters for the instance variables of FootballClub

    public int getNumWins() {
        return numWins;
    }

    public int getNumDraws() {
        return numDraws;
    }

    public int getNumDefeats() {
        return numDefeats;
    }

    public int getGoalsReceived() {
        return goalsReceived;
    }

    public int getGoalsScored() {
        return goalsScored;
    }

    public int getPoints() {
        return points;
    }

    public int getNumOfMatches() {
        return numOfMatches;
    }

    public int getGoalDifference() {
        return goalsScored - goalsReceived;
    }

    //generating setters for the instance variables of FootballClub

    public void setNumWins(int numWins) {
        this.numWins = numWins;
    }

    public void setNumDraws(int numDraws) {
        this.numDraws = numDraws;
    }

    public void setNumDefeats(int numDefeats) {
        this.numDefeats = numDefeats;
    }

    public void setGoalsReceived(int goalsReceived) {
        this.goalsReceived = goalsReceived;
    }

    public void setGoalsScored(int goalsScored) {
        this.goalsScored = goalsScored;
    }

    public void setPoints(int points) {
        this.points = points;
    }

    public void setNumOfMatches(int numOfMatches) {
        this.numOfMatches = numOfMatches;
    }

    @Override
    public String toString() {
        return super.toString() +
                "\nNumber of wins : " + numWins +
                "\nNumber of draws : " + numDraws +
                "\nNumber of defeats : " + numDefeats +
                "\nGoals received : " + goalsReceived +
                "\nGoals scored : " + goalsScored +
                "\nPoints : " + points +
                "\nNumber of matches played : " + numOfMatches;
    }

    //generating an overridden toString method for FootballClub
    @Override
    public int compareTo(FootballClub footballClub) {
        if(this.getPoints() > footballClub.getPoints()) {
            return -1;
        }else if(this.getPoints() < footballClub.getPoints()) {
            return 1;
        }else if(this.getGoalDifference() > footballClub.getGoalDifference()) {
            return -1;
        }else {
            return 1;
        }
    }
}
