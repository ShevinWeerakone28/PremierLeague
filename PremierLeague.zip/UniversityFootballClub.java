package lk.programming.OOPCoursework;

public class UniversityFootballClub extends FootballClub {

    //declaring all the instance variables of UniversityFootballClub
    private String uniName;

    //default UniversityFootballClub constructor
    public UniversityFootballClub() {}

    //parameterized UniversityFootballClub constructor
    public UniversityFootballClub(String uniName) {
        this.uniName = uniName;
    }

    //generating getters for the instance variables of UniversityFootballClub

    public String getUniName() {
        return uniName;
    }

    //generating setters for the instance variables of UniversityFootballClub

    public void setUniName(String uniName) {
        this.uniName = uniName;
    }

    //generating an overridden toString method for UniversityFootballClub
    @Override
    public String toString() {
        return super.toString() +
                "University name : " + uniName;
    }
}
