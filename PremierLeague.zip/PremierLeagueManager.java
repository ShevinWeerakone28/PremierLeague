package lk.programming.OOPCoursework;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class PremierLeagueManager implements LeagueManager {

    static Scanner sc = new Scanner(System.in);
    private static ArrayList<FootballClub> footballClubArray = new ArrayList<FootballClub>();  //creating an ArrayList with FootballClub objects
    //declaring all the variables
    private static String clubName;
    private static String location;
    private static int telNum;
    private static int numWins;
    private static int numDraws;
    private static int numDefeats;
    private static int goalsReceived;
    private static int goalsScored;
    private static int points;
    private static int numOfMatches;

    //method to allow the user to add a football club to the Premier Club
    public static void add() {

        //gathering the inputs about the information and statistics of the club from the user
        System.out.print("Enter the name of the club which you wish to add to the Premier League : ");
        sc.nextLine();
        clubName = sc.nextLine();
        System.out.print("Enter the location of " + clubName + " : ");
        location = sc.nextLine();
        System.out.print("Enter the telephone number of " + clubName + " : ");
        telNum = sc.nextInt();
        System.out.print("Enter the number of wins for " + clubName + " : ");
        numWins = sc.nextInt();
        System.out.print("Enter the number of draws for " + clubName + " : ");
        numDraws = sc.nextInt();
        System.out.print("Enter the number of defeats for " + clubName + " : ");
        numDefeats = sc.nextInt();
        System.out.print("Enter the number of goals received by " + clubName + " : ");
        goalsReceived = sc.nextInt();
        System.out.print("Enter the number of goals scored by " + clubName + " : ");
        goalsScored = sc.nextInt();
        System.out.print("Enter the number of points of " + clubName + " : ");
        points = sc.nextInt();
        System.out.print("Enter the number of matches played by " + clubName + " : ");
        numOfMatches = sc.nextInt();

        //creating a footballClub object and adding it to the footballClubArray
        FootballClub footballClub = new FootballClub(clubName, location, telNum, numWins, numDraws, numDefeats,
                goalsReceived, goalsScored, points, numOfMatches);
        footballClubArray.add(footballClub);

        //success message
        System.out.println(clubName + " has been successfully added to the Premier League!");
    }

    //method to allow the user to delete a specific football club from the Premier League
    public static void delete() {

        //displaying to the user the football clubs that are currently existing in the Premier League
        System.out.println("The football clubs currently in the Premier League are : ");
        for(int i = 0; i < footballClubArray.size(); i++) {
            System.out.println(footballClubArray.get(0).getClubName());
        }

        //getting the club name to be deleted input from the user
        System.out.print("\nEnter the name of the club that you wish to delete : ");
        sc.nextLine();
        String deleteClub = sc.nextLine();

        /* iterating through the footballClubArray until the club name matches the user input and then deleting the matching club name object
        from the footballClubArray */
        for(int i = 0; i < footballClubArray.size(); i++) {
            if(deleteClub.equals(footballClubArray.get(i).getClubName())) {
                footballClubArray.remove(i);
                System.out.println(clubName + " has been successfully deleted from the Premier League!");  //success message
            }
        }
    }

    //method to display the various statistics for a selected club
    public static void displayStats() {

        //getting the user to input the club name of the club for which he wishes to view the statistics
        System.out.print("Enter the name of the club for which you wish the statistics to be displayed : ");
        sc.nextLine();
        String clubDisplay = sc.nextLine();
        System.out.println();

        /* iterating through the footballClubArray until the club name matches the user input and then displaying the various statistics
        for that selected club */
        for(int i = 0; i < footballClubArray.size(); i++) {
            if(clubDisplay.equals(footballClubArray.get(i).getClubName())) {
                FootballClub footballClub = new FootballClub(clubName, location, telNum, numWins, numDraws, numDefeats,
                        goalsReceived, goalsScored, points, numOfMatches);
                System.out.println(footballClub.toString());
            }
        }
    }

    //method to display the Premier League Table
    public static void displayPLTable() {

        //sorting the football club objects in the footballClubArray ArrayList
        Collections.sort(footballClubArray);
        System.out.println("Premier League Table");

        //printing the start and headings of the Premier League Table
        System.out.println("-----------------------------------------------------------------------------------------------------" +
                "-----------------------------------------------------------------\n" +
                "|      Club Name     |      Points     | Goal Difference |  No. of Matches |   No. of Wins   |   No. of Draws  |" +
                "  No. of Defeats |   Goals Scored  |  Goals Received |" +
                "\n-----------------------------------------------------------------------------------------------------" +
                "-----------------------------------------------------------------");

        //for loop to make sure the statistics of all the football objects in the footballClubArray are displayed
        for(int i = 0; i < footballClubArray.size(); i++) {

            //printing the club's name of the specific football object
            String clName = footballClubArray.get(i).getClubName();
            //checking if the club name is already 20 characters or not
            if(clName.length() <= 20) {
                for(int i2 = 0; i2 < (20 - footballClubArray.get(i).getClubName().length()); i2++) {
                    //adding only a single space if the clName has an odd number of characters and the string length is currently 19
                    if( ((footballClubArray.get(i).getClubName().length() % 2) != 0) && (clName.length() == 19) ) {
                        clName = clName + " ";
                    }else if(clName.length() < 20) {
                        //adding a space at the start and the end of clName if the string length is less than 20
                        clName = " " + clName + " ";
                    }
                }
            }
            //printing the clName in the Premier League table with the appropriate spacing
            System.out.print("|" + clName + "|");

            //printing the club's points of the specific football object
            String clPoints = String.valueOf(footballClubArray.get(i).getPoints());
            //checking if the club points are already 17 characters or not
            if(clPoints.length() <= 17) {
                for(int i2 = 0; i2 < (17 - String.valueOf(footballClubArray.get(i).getPoints()).length()); i2++) {
                    //adding only a single space if the clPoints has an even number of characters and the string length is currently 16
                    if( ((String.valueOf(footballClubArray.get(i).getPoints()).length() % 2) == 0) && (clPoints.length() == 16) ) {
                        clPoints = clPoints + " ";
                    }else if(clPoints.length() < 17) {
                        //adding a space at the start and the end of clPoints if the string length is less than 17
                        clPoints = " " + clPoints + " ";
                    }
                }
            }
            //printing the clPoints in the Premier League table with the appropriate spacing
            System.out.print(clPoints + "|");

            //printing the club's goal difference of the specific football object
            String clGoalDiff = String.valueOf(footballClubArray.get(i).getGoalDifference());
            //checking if the club goal difference is already 17 characters or not
            if(clGoalDiff.length() <= 17) {
                for(int i2 = 0; i2 < (17 - (String.valueOf(footballClubArray.get(i).getGoalDifference()).length())); i2++) {
                    //adding only a single space if clGoalDifference has an even number of characters and the string length is currently 16
                    if( (((String.valueOf(footballClubArray.get(i).getGoalDifference()).length()) % 2) == 0) && (clGoalDiff.length() == 16) ) {
                        clGoalDiff = clGoalDiff + " ";
                    }else if(clGoalDiff.length() < 17) {
                        //adding a space at the start and the end of clGoalDiff if the string length is less than 17
                        clGoalDiff = " " + clGoalDiff + " ";
                    }
                }
            }
            //printing the clGoalDiff in the Premier League table with the appropriate spacing
            System.out.print(clGoalDiff + "|");

            //printing the club's number of matches played of the specific football object
            String clMatches = String.valueOf(footballClubArray.get(i).getNumOfMatches());
            //checking if the club's number of matches is already 17 characters or not
            if(clMatches.length() <= 17) {
                for(int i2 = 0; i2 < (17 - (String.valueOf(footballClubArray.get(i).getNumOfMatches()).length())); i2++) {
                    //adding only a single space if clMatches has an even number of characters and the string length is currently 16
                    if( (((String.valueOf(footballClubArray.get(i).getNumOfMatches()).length()) % 2) == 0) && (clMatches.length() == 16) ) {
                        clMatches = clMatches + " ";
                    }else if(clMatches.length() < 17) {
                        //adding a space at the start and the end of clMatches if the string length is less than 17
                        clMatches = " " + clMatches + " ";
                    }
                }
            }
            //printing the clMatches in the Premier League table with the appropriate spacing
            System.out.print(clMatches + "|");

            //printing the club's number of wins of the specific football object
            String clWins = String.valueOf(footballClubArray.get(i).getNumWins());
            //checking if the club's number of wins is already 17 characters or not
            if(clWins.length() <= 17) {
                for(int i2 = 0; i2 < (17 - (String.valueOf(footballClubArray.get(i).getNumWins()).length())); i2++) {
                    //adding only a single space if clWins has an even number of characters and the string length is currently 16
                    if( (((String.valueOf(footballClubArray.get(i).getNumWins()).length()) % 2) == 0) && (clWins.length() == 16) ) {
                        clWins = clWins + " ";
                    }else if(clWins.length() < 17) {
                        //adding a space at the start and the end of clWins if the string length is less than 17
                        clWins = " " + clWins + " ";
                    }
                }
            }
            //printing the clWins in the Premier League table with the appropriate spacing
            System.out.print(clWins + "|");

            //printing the club's number of draws of the specific football object
            String clDraws = String.valueOf(footballClubArray.get(i).getNumDraws());
            //checking if the club's number of draws is already 17 characters or not
            if(clDraws.length() <= 17) {
                for(int i2 = 0; i2 < (17 - (String.valueOf(footballClubArray.get(i).getNumDraws()).length())); i2++) {
                    //adding only a single space if clDraws has an even number of characters and the string length is currently 16
                    if( (((String.valueOf(footballClubArray.get(i).getNumDraws()).length()) % 2) == 0) && (clDraws.length() == 16) ) {
                        clDraws = clDraws + " ";
                    }else if(clDraws.length() < 17) {
                        //adding a space at the start and the end of clDraws if the string length is less than 17
                        clDraws = " " + clDraws + " ";
                    }
                }
            }
            //printing the clDraws in the Premier League table with the appropriate spacing
            System.out.print(clDraws + "|");

            //printing the club's number of defeats of the specific football object
            String clDefeats = String.valueOf(footballClubArray.get(i).getNumDefeats());
            //checking if the club's number of defeats is already 17 characters or not
            if(clDefeats.length() <= 17) {
                for(int i2 = 0; i2 < (17 - (String.valueOf(footballClubArray.get(i).getNumDefeats()).length())); i2++) {
                    //adding only a single space if clDefeats has an even number of characters and the string length is currently 16
                    if( (((String.valueOf(footballClubArray.get(i).getNumDefeats()).length()) % 2) == 0) && (clDefeats.length() == 16) ) {
                        clDefeats = clDefeats + " ";
                    }else if(clDefeats.length() < 17) {
                        //adding a space at the start and the end of clDefeats if the string length is less than 17
                        clDefeats = " " + clDefeats + " ";
                    }
                }
            }
            //printing the clDefeats in the Premier League table with the appropriate spacing
            System.out.print(clDefeats + "|");

            //printing the club's goals scored of the specific football object
            String clGoalsScored = String.valueOf(footballClubArray.get(i).getGoalsScored());
            //checking if the club's goals scored is already 17 characters or not
            if(clGoalsScored.length() <= 17) {
                for(int i2 = 0; i2 < (17 - (String.valueOf(footballClubArray.get(i).getGoalsScored()).length())); i2++) {
                    //adding only a single space if clGoalsScored has an even number of characters and the string length is currently 16
                    if( (((String.valueOf(footballClubArray.get(i).getGoalsScored()).length()) % 2) == 0) && (clGoalsScored.length() == 16) ) {
                        clGoalsScored = clGoalsScored + " ";
                    }else if(clGoalsScored.length() < 17) {
                        //adding a space at the start and the end of clGoalsScored if the string length is less than 17
                        clGoalsScored = " " + clGoalsScored + " ";
                    }
                }
            }
            //printing the clGoalsScored in the Premier League table with the appropriate spacing
            System.out.print(clGoalsScored + "|");

            //printing the club's goals received of the specific football object
            String clGoalsReceived = String.valueOf(footballClubArray.get(i).getGoalsReceived());
            //checking if the club's goals received is already 17 characters or not
            if(clGoalsReceived.length() <= 17) {
                for(int i2 = 0; i2 < (17 - (String.valueOf(footballClubArray.get(i).getGoalsReceived()).length())); i2++) {
                    //adding only a single space if clGoalsReceived has an even number of characters and the string length is currently 16
                    if( (((String.valueOf(footballClubArray.get(i).getGoalsReceived()).length()) % 2) == 0) && (clGoalsReceived.length() == 16) ) {
                        clGoalsReceived = clGoalsReceived + " ";
                    }else if(clGoalsReceived.length() < 17) {
                        //adding a space at the start and the end of clGoalsReceived if the string length is less than 17
                        clGoalsReceived = " " + clGoalsReceived + " ";
                    }
                }
            }
            //printing the clGoalsReceived in the Premier League table with the appropriate spacing
            System.out.print(clGoalsReceived + "|\n");

        }
        //printing the end of the Premier League Table structure
        System.out.println("-----------------------------------------------------------------------------------------------------" +
                "-----------------------------------------------------------------\n");
    }

    //main method
    public static void main(String[] args) {

        String quit = "no";  //initialising quit variable that is used in order to quit the program

        //menu using a while loop that will run endlessly until the user decides to quit
        while (!quit.equals("yes")) {

            //printing the menu in console with the relevant options provided to the user
            System.out.print("\nMenu :) \n" +
                    "Press 0 to : Quit the program \n" +
                    "Press 1 to : Create a new football club and add it in the premier league \n" +
                    "Press 2 to : Delete (relegate) an existing club from the premier league \n" +
                    "Press 3 to : Display the various statistics for a selected club \n" +
                    "Press 4 to : Display the Premier League Table \n\n" +
                    "Enter option number here : ");

            //obtaining the user's input of an option number
            int input = sc.nextInt();
            System.out.println();

            //switch case in order to call the relevant methods, or quit the program, based on the option number entered by the user
            switch (input) {

                //case when the user has selected to quit the program
                case 0:
                    quit = "yes";
                    System.out.println("Program ended.");
                    break;

                //case when the user has selected to add a football club to the Premier League
                case 1:
                    add();
                    break;

                //case when the user has selected to delete a football club from the Premier League
                case 2:
                    delete();
                    break;

                //case when the user has selected to display the statistics of a specific football club
                case 3:
                    displayStats();
                    break;

                //case when the user has selected to display the Premier League Table
                case 4:
                    displayPLTable();
                    break;
            }
        }
    }
}
