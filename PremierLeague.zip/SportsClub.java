package lk.programming.OOPCoursework;

public class SportsClub {

    //declaring all the instance variables of SportsClub
    private String clubName;
    private String location;
    private int telNum;

    //default SportsClub constructor
    public SportsClub() {}

    //parameterized SportsClub constructor
    public SportsClub(String clubName, String location, int telNum) {
        this.clubName = clubName;
        this.location = location;
        this.telNum = telNum;
    }

    //generating getters for the instance variables of SportsClub

    public String getClubName() {
        return clubName;
    }

    public String getLocation() {
        return location;
    }

    public int getTelNum() {
        return telNum;
    }

    //generating setters for the instance variables of SportsClub

    public void setClubName(String clubName) {
        this.clubName = clubName;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setTelNum(int telNum) {
        this.telNum = telNum;
    }

    //generating a toString method for SportsClub
    public String toString() {
        return "Club name : " + clubName +
                "\nLocation : " + location +
                "\nTelephone Number : " + telNum;
    }
}
