package lk.programming.OOPCoursework;

public class SchoolFootballClub extends FootballClub {

    //declaring all the instance variables of SchoolFootballClub
    private String sclName;

    //default SchoolFootballClub constructor
    public SchoolFootballClub() {}

    //parameterized SchoolFootballClub constructor
    public SchoolFootballClub(String sclName) {
        this.sclName = sclName;
    }

    //generating getters for the instance variables of SchoolFootballClub

    public String getSclName() {
        return sclName;
    }

    //generating setters for the instance variables of SchoolFootballClub

    public void setSclName(String sclName) {
        this.sclName = sclName;
    }

    //generating an overridden toString method for SchoolFootballClub
    @Override
    public String toString() {
        return super.toString() +
                "School name : " + sclName;
    }
}
