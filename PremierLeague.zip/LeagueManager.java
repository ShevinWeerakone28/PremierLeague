package lk.programming.OOPCoursework;

public interface LeagueManager {
}
